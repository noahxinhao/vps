cd /opt/nginx/sbin
sudo ./nginx -c /opt/nginx/conf/nginx.conf
